const express = require("express");
const router = express.Router();

var ctrlLocations7 = require("../Controllers/cont1");
var ctrlLocations6 = require("../Controllers/cont2");

router.post("/single-post.html/", ctrlLocations7.createCandidate);  //storing values hard
router.get("/single-post.html/:roll_num", ctrlLocations7.viewCandidate);
router.patch("/contact.html/",ctrlLocations6.UpdatePW);
router.get("/index.html/:candidate",ctrlLocations6.viewVotes);

router.get("/index.html/",ctrlLocations6.Results);
router.patch("/index.html/",ctrlLocations6.castVote);

router.post("/contact.html", ctrlLocations7.creating);

module.exports = router;
