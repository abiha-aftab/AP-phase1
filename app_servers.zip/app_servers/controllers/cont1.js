var mongoose = require("mongoose");

var candidate1 = mongoose.model("candidate1");
var cand1=require('../models/candidate');

module.exports.test = function(req, res) {
  res.render("single-post.html", { status: "success" });
};


module.exports.createCandidate = function(req, res) {
  candidate1.create(
    {
      username: "iuiui qwuii",
      batch:2017,
      roll_num:"16L-4021",
      votes:190,
      school:"Beaconhouse School System",
      College:"Kinnaird College for Women University",
      Experience:"Netsol: Worked on developing desktop based applications using JAVA",
      Password:"123",
      Skills: [
          "hardworking","good at team work"
      ]
    },
    function(err, candi) {
      if (err) {
        console.log(err);
      } else {
        //console.log(candi);
        res.render("single-post.html", { data: candi });
      }
    }
  );
};

module.exports.viewCandidate = function(req, res) {
	//console.log(req.params);
    var user=req.params.roll_num;
    cand1.find({
      roll_num: user

    }).exec(function(err,candInfo){
      if (err) return handleError(err);
      else {
        //console.log(payment);
        //console.log(payment1);
      
      
        res.render("single-post.html", { data: candInfo });

      }

    });			
  }
  /*
  module.exports.updatePW = function(req, res) {
			var pass=req.params.pass;
			//console.log("name"+name);
						user1.update({ username: globalstring }, { $set: {  password: pass}}, function (err, userr) {
							if (err) return handleError(err);
							res.send(userr);
						  });
				//}
				//)
			}; 
*/
module.exports.creating = function(req, res) {
console.log("--req.body--"+ req.body);
if (req.body.username && req.body.batch && req.body.roll_num && req.body.school && req.body.College) {
    var canddb = {
      Skills : req.body.Skills,
      Experience: req.body.Experience,
      username: req.body.username,
      password: req.body.password,
	  batch: req.body.batch,
	  roll_num:req.body.roll_num,
	  school:req.body.school,
	  College:req.body.College,
	  votes:0
    }

    //use schema.create to insert data into the db
    candidate1.create(canddb, function (err, candidate) {
      if (err){
        console.log(err);
      } else { 
        globalstring=req.body.roll_num;
        
        res.redirect('/');

      }
    });
  }
};


module.exports.UpdatePW = function(req, res) {
    var pass=req.body.password;
	globalstring="16L-4329";
    console.log("pass"+pass+"   global"+globalstring);
                db.cand1.updateOne({ username: globalstring }, { $set: {Password: pass}}, function (err, userr) {
                    if (err) return handleError(err);
                    res.send(userr);
                  });
        //}
        //)
    }; 