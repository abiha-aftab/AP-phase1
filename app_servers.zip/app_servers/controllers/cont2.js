var mongoose = require("mongoose");
var async= require("async");
var candidate1 = mongoose.model("candidate1");
var cand1=require('../models/candidate');
var usersdb=  mongoose.model("usersdb");
var user1=require('../models/usersdb');


module.exports.test = function(req, res) {
  res.render("single-post.html", { status: "success" });
};

module.exports.UpdatePW = function(req, res) {
    var pass=req.body.password;
	globalstring="16L-4321";
    console.log("pass"+pass+"   global"+globalstring);
                user1.updateOne({ roll_number: globalstring }, { $set: {Password: pass}}, function (err, userr) {
                    if (err) return handleError(err);
                    res.send(userr);
                  });
        //}
        //)
    }; 
	
	
module.exports.Results= function(req,res){
	
	cand1.aggregate(
		[
			{
				$group:
				{
					_id:"$batch",
					maxVotes:{$max: "$votes"}	
				}
			}
		]
		).exec(function(err,maxV){
			console.log(maxV);
		})
		
}	
	
	
module.exports.castVote = function(req, res) {
  async.parallel(
    {
      allbooks: function(callback) {
		cand1.find({
		roll_num: req.body.roll
		}).exec(callback);
      },
      newarrivals: function(callback) {
		user1.updateOne({ roll_number: globalstring }, { $set: {votedFor: req.body.roll}}).exec(callback);
      }
    },
    function(err, results) {
      if (err) {
        return next(err);
      }
      if (results.allbooks == null) {
        // No results.
		console.log("cand not found");
        var err = new Error("cand not found");
        err.status = 404;
        return next(err);
      }

      // Successful, so render.
    cand1.updateOne({ roll_num: req.body.roll }, { $set: {votes: results.allbooks[0]["votes"]+1}}, function (err, userr) {
       if (err) console.log("err");
        res.send(userr);
        })
    }
  );
};

module.exports.viewVotes= function(req,res){
	var candidate= req.params.candidate; 
	cand1.find({
      roll_num: candidate

    }).exec(function(err,candInfo){
      if (err) return handleError(err);
      else {
        console.log(candInfo[0]["votes"]);
        //console.log(payment1);
      
      
        res.render("single-post.html", { data: candInfo[0]["votes"]});

      }

    });	
}